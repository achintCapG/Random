import { useState, useRef } from "react";

export default function Player() {

  const playerName = useRef();

const [player, setPlayer] = useState('');
//  const [submitted, setSubmit] = useState(false);

//  function handleChange(event) {
//     setSubmit(false);
//     setPlayer(event.target.value);
//  }

 function handleSubmit() {
  setPlayer(playerName.current.value);
  playerName.current.value= '';
 }

  return (
    <section id="player">
      <h2>Welcome {player == '' ? 'Enter Name' : player}</h2>
      <p>
        <input ref={playerName} type="text" />
        <button onClick={handleSubmit}>Set Name</button>
      </p>
    </section>
  );
}